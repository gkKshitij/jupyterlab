#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd


# In[2]:


import numpy as np


# In[3]:


masterpath =r'C:\Users\saurav\M76 Analytics\DATA cleansing Assignment 1\Assignment2_70_20/'


# In[4]:


df = pd.read_csv('1_completeResults17-20siteCleanedUp.csv')


# In[5]:


df['c'] = df.fillna('0')['Site']+'%'+df.fillna('0')['Equipment_Type']+'%'+df.fillna('0')['MODEL'] 


# In[6]:


List = df['c'].unique()


# Total 13179 unique (Total = 42086)  Combination with 'Site'+ 'Equipment_Type' + 'MODEL'

# In[7]:


(len(List))


# In[8]:


len(df['c'])


# In[9]:


def countX(lst, x): 
    count = 0
    for ele in lst: 
        if (ele == x): 
            count = count + 1
    return count 


# In[10]:


for i in np.arange(len(List)):
    Count = countX(df['c'],List[i])
    List[i] = List[i]+'%'+str(Count)
    


# In[11]:


List[0].split('%')


# In[12]:


column_names = ['Site','Equipment_Type','MODEL','Count']


# In[13]:


df2 = pd.DataFrame(columns = column_names)


# In[14]:


df2['index_pain de raha'] = np.arange(len(List))


# In[16]:


for i in np.arange(len(List)):
    p = List[i].split('%')
    if len(p) != 4:
        print('Cant use % for splitting')
        print(i)
    df2['Site'].iloc[i] = p[0]
    df2['Equipment_Type'].iloc[i] = p[1]
    df2['MODEL'].iloc[i] = p[2]
    df2['Count'].iloc[i] = int(p[3])


# In[17]:


df2.sort_values(by = 'Count',inplace = True,ascending = False)


# In[18]:


df2


# In[19]:


df2['Site'].replace({"0": np.nan}, inplace=True)


# In[20]:


df2['Equipment_Type'].replace({"0": np.nan}, inplace=True)


# In[21]:


df2['MODEL'].replace({"0": np.nan}, inplace=True)


# In[22]:


df2.drop('index_pain de raha',axis = 1,inplace=True)


# In[24]:


df2


# In[25]:


df2.to_excel (masterpath+'Count.xlsx',index = False, header=True)


# 70% Total = ? & of Combination Calculation

# In[35]:


Total_Count = df2['Count'].sum()
Total_Count


# In[38]:


Total_Combinations = len(df2)
Total_Combinations


# In[45]:


seventy_percentofTotal_Count = Total_Count*(0.7)
seventy_percent


# In[40]:


twenty_percentofTotal_Combinations = Total_Combinations*(0.2)
twenty_percentofTotal_Combinations


# In[48]:


for i in np.arange(len(List)):
    sum_tillnow = df2['Count'][:i].sum()
    if sum_tillnow > seventy_percentofTotal_Count:
        print(i)
        sum_break = i
        break


# In[50]:


percent = (sum_break/Total_Combinations)*100
percent


# 70% of Total = 18.12 % of Combination Calculation

# In[ ]:





# In[ ]:





# ____
# 
# 
# Please Ignore this part as of now

# column_names2 = df.columns

# df4 = pd.DataFrame(columns = column_names2)

# for i in np.arange(len(df)):
#     p = df['Site'] == df2['Site'][i]
#     q = df['Equipment_Type']== df2['Equipment_Type'][i]
#     r = df['MODEL'] == df2['MODEL'][i]
#     final = p & q & r
#     df3 = df[final]
#     df4 = pd.concat([df3,df4])
# 

# df4
# 
# ____
